/**
 * Created by manojpolisetti on 16/10/15.
 */
public class InsufficientFuelException extends Exception {
    public InsufficientFuelException(String message) {
        super(message);
    }
}
